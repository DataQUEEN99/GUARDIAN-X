"""
GUARDIAN-X FastAPI Application Backend
Provides REST endpoints for multimodal threat analysis, security logs, and health status.
"""

import os
import base64
from typing import Optional, Dict, Any, List
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from agents import default_orchestrator, GuardianRequest, GuardianResponse, Decision
from security_logging import default_logger, get_recent_events, get_statistics
from memory import default_attack_memory
from guardrails.action_firewall import REGISTERED_TOOLS

app = FastAPI(
    title="GUARDIAN-X Multimodal Multi-Agent Guardrails & Action Firewall",
    description="Zero-trust security perimeter detecting visual and textual threats with Action Firewall.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequestPayload(BaseModel):
    text: Optional[str] = Field(default="", description="Text prompt to analyze")
    image_base64: Optional[str] = Field(default=None, description="Base64 encoded image string")
    metadata: Dict[str, Any] = Field(default_factory=dict)


@app.get("/health", tags=["System"])
def health_check() -> Dict[str, Any]:
    """Health status and diagnostic information."""
    try:
        stats = default_logger.get_statistics()
        db_healthy = True
    except Exception:
        db_healthy = False

    return {
        "status": "healthy" if db_healthy else "degraded",
        "service": "guardian-x-guardrails",
        "version": "1.0.0",
        "database_connected": db_healthy,
        "attack_memory_records": len(default_attack_memory.attacks),
        "registered_tools": sorted(list(REGISTERED_TOOLS)),
        "policy_engine_active": True,
        "action_firewall_active": True
    }


@app.post("/analyze", response_model=GuardianResponse, tags=["Guardrails"])
def analyze_request(payload: AnalyzeRequestPayload) -> GuardianResponse:
    """
    Primary JSON analysis endpoint.
    Processes user text and optional base64 image through the full GUARDIAN-X pipeline.
    """
    if not payload.text and not payload.image_base64:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either 'text' or 'image_base64' must be provided."
        )

    guardian_req = GuardianRequest(
        text=payload.text,
        image_base64=payload.image_base64,
        metadata=payload.metadata
    )
    return default_orchestrator.process_request(guardian_req)


@app.post("/analyze/upload", response_model=GuardianResponse, tags=["Guardrails"])
async def analyze_with_image_upload(
    text: str = Form(default=""),
    image: Optional[UploadFile] = File(default=None)
) -> GuardianResponse:
    """
    Multipart form-data endpoint supporting direct image file upload.
    """
    image_b64 = None
    if image:
        content = await image.read()
        if content:
            image_b64 = base64.b64encode(content).decode("utf-8")

    if not text and not image_b64:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either 'text' or an image file must be uploaded."
        )

    guardian_req = GuardianRequest(
        text=text,
        image_base64=image_b64,
        metadata={"filename": image.filename if image else None}
    )
    return default_orchestrator.process_request(guardian_req)


@app.get("/api/events", tags=["Security Forensics"])
def list_security_events(
    limit: int = Query(default=50, ge=1, le=500),
    decision: Optional[str] = Query(default=None, description="Filter by ALLOW, TRANSFORM, or BLOCK")
) -> List[Dict[str, Any]]:
    """Retrieve historical security audit events from SQLite."""
    return get_recent_events(limit=limit, decision_filter=decision)


@app.get("/api/stats", tags=["Security Forensics"])
def get_security_statistics() -> Dict[str, Any]:
    """Retrieve aggregated security statistics and threat breakdown."""
    return get_statistics()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
