"""
Guardian-X Safe Calculator Tool
Evaluates mathematical expressions using strict AST parsing without using eval() or exec().
"""

import ast
import operator
from typing import Dict, Any, Union

# Whitelisted operators mapped to python operator functions
ALLOWED_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def _eval_ast_node(node: ast.AST) -> Union[int, float]:
    """Recursively evaluates AST node only if it belongs to whitelisted math operations."""
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError(f"Disallowed constant type: {type(node.value)}")

    elif isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in ALLOWED_OPERATORS:
            raise ValueError(f"Disallowed binary operator: {op_type.__name__}")
        left = _eval_ast_node(node.left)
        right = _eval_ast_node(node.right)

        # Guard against zero division and excessive exponentiation
        if op_type in (ast.Div, ast.FloorDiv, ast.Mod) and right == 0:
            raise ZeroDivisionError("Division by zero is not allowed.")
        if op_type == ast.Pow and (right > 100 or left > 10000):
            raise OverflowError("Exponentiation exceeds security calculation bounds.")

        return ALLOWED_OPERATORS[op_type](left, right)

    elif isinstance(node, ast.UnaryOp):
        op_type = type(node.op)
        if op_type not in ALLOWED_OPERATORS:
            raise ValueError(f"Disallowed unary operator: {op_type.__name__}")
        operand = _eval_ast_node(node.operand)
        return ALLOWED_OPERATORS[op_type](operand)

    else:
        raise ValueError(f"Disallowed syntax element: {type(node).__name__}. Only pure arithmetic is allowed.")


class SafeCalculator:
    """Safe arithmetic calculator tool exposed through Action Firewall."""
    name = "calculator"

    @staticmethod
    def calculate(expression: str) -> Dict[str, Any]:
        """
        Safely evaluates an arithmetic expression string.
        Returns a dict with success status, result, or error.
        """
        if not expression or not isinstance(expression, str):
            return {"success": False, "error": "Expression must be a non-empty string."}

        # Clean string
        clean_expr = expression.strip()
        if len(clean_expr) > 200:
            return {"success": False, "error": "Expression exceeds maximum length of 200 characters."}

        try:
            tree = ast.parse(clean_expr, mode="eval")
            result = _eval_ast_node(tree.body)
            # Format float nicely if it's an integer value
            if isinstance(result, float) and result.is_integer():
                result = int(result)
            return {"success": True, "result": result, "expression": clean_expr}
        except ZeroDivisionError as zde:
            return {"success": False, "error": str(zde)}
        except OverflowError as oe:
            return {"success": False, "error": str(oe)}
        except Exception as e:
            return {"success": False, "error": f"Invalid arithmetic expression: {str(e)}"}
