"""
Guardian-X Sandboxed Virtual Filesystem
Isolates all filesystem operations strictly within a mock directory structure.
Prevents any deletion, modification, or access to real host operating system files.
"""

from pathlib import Path
from typing import Dict, Any, List, Optional


class VirtualSandbox:
    """
    Sandboxed virtual filesystem tool.
    Strictly forbids modifying or reading anything outside the sandbox directory root.
    """
    name = "virtual_sandbox"

    def __init__(self, sandbox_root: str = "tools/virtual_sandbox"):
        self.root_path = Path(sandbox_root).resolve()
        self._init_sandbox_environment()

    def _init_sandbox_environment(self) -> None:
        """Seed virtual sandbox with standard mock folders and initial files."""
        temp_dir = self.root_path / "temp"
        data_dir = self.root_path / "data"
        protected_dir = self.root_path / "protected"

        temp_dir.mkdir(parents=True, exist_ok=True)
        data_dir.mkdir(parents=True, exist_ok=True)
        protected_dir.mkdir(parents=True, exist_ok=True)

        # Seed harmless files
        (temp_dir / "example.txt").write_text("Temporary log entry: application normal operation.", encoding="utf-8")
        (temp_dir / "cache.tmp").write_text("session_cache_id=8923487", encoding="utf-8")
        (data_dir / "analytics.json").write_text('{"status": "ok", "active_users": 42}', encoding="utf-8")
        (data_dir / "user_notes.txt").write_text("Meeting at 3 PM regarding AI security.", encoding="utf-8")

        # Seed protected files (used to test Action Firewall blocking)
        (protected_dir / "system_config.txt").write_text("CONFIDENTIAL: CORE_SYSTEM_FIREWALL_RULES_V1", encoding="utf-8")
        (protected_dir / "credentials.env").write_text("MOCK_ROOT_TOKEN=super_secret_virtual_token_do_not_read", encoding="utf-8")

    def _resolve_safe_path(self, relative_path: str) -> Optional[Path]:
        """
        Resolves a virtual target path, verifying it does NOT escape the sandbox root.
        Returns resolved Path if safe, or None if path escapes the sandbox.
        """
        if not relative_path:
            return None

        # Strip leading slashes/backslashes to treat strictly as relative
        clean_rel = relative_path.replace("\\", "/").strip().lstrip("/")
        if clean_rel.startswith("sandbox/"):
            clean_rel = clean_rel[len("sandbox/"):]
        elif clean_rel.startswith("tools/virtual_sandbox/"):
            clean_rel = clean_rel[len("tools/virtual_sandbox/"):]

        # Reject path traversal tokens
        if ".." in clean_rel.split("/"):
            return None

        target_path = (self.root_path / clean_rel).resolve()
        try:
            target_path.relative_to(self.root_path)
            return target_path
        except ValueError:
            # Traversal escape detected!
            return None

    def read_file(self, target_path: str) -> Dict[str, Any]:
        """Read content of a file within the sandbox."""
        resolved = self._resolve_safe_path(target_path)
        if not resolved:
            return {"success": False, "error": "Path traversal or invalid sandbox target path."}

        if not resolved.exists():
            return {"success": False, "error": f"File '{target_path}' does not exist in sandbox."}

        if resolved.is_dir():
            return {"success": False, "error": f"Target '{target_path}' is a directory, not a file."}

        try:
            content = resolved.read_text(encoding="utf-8")
            return {"success": True, "path": target_path, "content": content}
        except Exception as e:
            return {"success": False, "error": f"Failed reading file: {str(e)}"}

    def write_file(self, target_path: str, content: str) -> Dict[str, Any]:
        """Write content to a file inside the sandbox."""
        resolved = self._resolve_safe_path(target_path)
        if not resolved:
            return {"success": False, "error": "Path traversal or invalid sandbox target path."}

        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(content, encoding="utf-8")
            return {"success": True, "path": target_path, "bytes_written": len(content)}
        except Exception as e:
            return {"success": False, "error": f"Failed writing file: {str(e)}"}

    def delete_file(self, target_path: str) -> Dict[str, Any]:
        """Delete a file inside the sandbox."""
        resolved = self._resolve_safe_path(target_path)
        if not resolved:
            return {"success": False, "error": "Path traversal or invalid sandbox target path."}

        if not resolved.exists():
            return {"success": False, "error": f"File '{target_path}' does not exist in sandbox."}

        if resolved.is_dir():
            return {"success": False, "error": f"Target '{target_path}' is a directory. Cannot delete with delete_file."}

        try:
            resolved.unlink()
            return {"success": True, "path": target_path, "message": f"Successfully deleted '{target_path}' from sandbox."}
        except Exception as e:
            return {"success": False, "error": f"Failed deleting file: {str(e)}"}

    def list_dir(self, target_path: str = "") -> Dict[str, Any]:
        """List files and folders within a sandbox directory."""
        clean_target = target_path if target_path else "."
        resolved = self._resolve_safe_path(clean_target)
        if not resolved or not resolved.exists() or not resolved.is_dir():
            return {"success": False, "error": f"Target '{target_path}' is not a valid sandbox directory."}

        items = []
        for child in resolved.iterdir():
            items.append({
                "name": child.name,
                "is_dir": child.is_dir(),
                "size_bytes": child.stat().st_size if child.is_file() else 0
            })
        return {"success": True, "directory": target_path, "items": items}


# Global sandbox instance
default_sandbox = VirtualSandbox()
