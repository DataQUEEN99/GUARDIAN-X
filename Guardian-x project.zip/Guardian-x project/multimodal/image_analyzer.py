"""
Guardian-X Image Analyzer
Processes visual inputs via Vision-capable LLMs (OpenAI) with robust offline fallback
for EXIF/metadata inspection, structural verification, and image-embedded text detection.
"""

import os
import io
import base64
import json
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
from PIL import Image, ExifTags


SUPPORTED_FORMATS = {"PNG", "JPEG", "JPG", "WEBP", "GIF", "BMP"}


class ImageAnalyzer:
    """
    Multimodal Image Analyzer.
    Extracts text, intent, and visual elements from uploaded images.
    Feeds normalized visual content into the unified Threat Detection Agent.
    """

    def __init__(self, api_key: Optional[str] = None, model_name: str = "gpt-4o-mini"):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model_name = model_name or os.getenv("VISION_MODEL_NAME", "gpt-4o-mini")

    @staticmethod
    def load_image(image_input: Any) -> Tuple[Optional[Image.Image], Optional[str], Optional[str]]:
        """
        Loads and validates an image from either a file path, bytes, or a base64 string.
        Returns (PIL.Image, format_name, error_message).
        """
        try:
            image: Optional[Image.Image] = None

            if isinstance(image_input, (str, Path)) and os.path.exists(str(image_input)):
                image = Image.open(str(image_input))
            elif isinstance(image_input, str):
                # Attempt to decode as base64
                clean_b64 = image_input
                if "base64," in clean_b64:
                    clean_b64 = clean_b64.split("base64,")[1]
                image_bytes = base64.b64decode(clean_b64)
                image = Image.open(io.BytesIO(image_bytes))
            elif isinstance(image_input, bytes):
                image = Image.open(io.BytesIO(image_input))
            elif isinstance(image_input, Image.Image):
                image = image_input
            else:
                return None, None, f"Unsupported image input type: {type(image_input)}"

            img_format = (image.format or "PNG").upper()
            if img_format not in SUPPORTED_FORMATS:
                return None, None, f"Unsupported image format: '{img_format}'. Supported formats: {sorted(list(SUPPORTED_FORMATS))}"

            # Verify image integrity
            image.verify()
            # Reopen after verify() because verify() can leave file pointer at EOF
            if isinstance(image_input, (str, Path)) and os.path.exists(str(image_input)):
                image = Image.open(str(image_input))
            elif isinstance(image_input, str):
                image = Image.open(io.BytesIO(base64.b64decode(clean_b64)))
            elif isinstance(image_input, bytes):
                image = Image.open(io.BytesIO(image_input))

            return image, img_format, None

        except Exception as e:
            return None, None, f"Corrupted or invalid image: {str(e)}"

    def _analyze_with_vision_api(self, image: Image.Image, img_format: str) -> Optional[str]:
        """
        Leverages OpenAI Vision model to inspect image contents and extract any embedded text or instructions.
        """
        if not self.api_key or "your_openai_api_key" in self.api_key:
            return None

        try:
            from openai import OpenAI
            client = OpenAI(api_key=self.api_key)

            buffered = io.BytesIO()
            save_fmt = "PNG" if img_format == "PNG" else "JPEG"
            image.save(buffered, format=save_fmt)
            b64_data = base64.b64encode(buffered.getvalue()).decode("utf-8")
            mime_type = f"image/{save_fmt.lower()}"

            prompt = (
                "You are an AI security vision analyzer for GUARDIAN-X. "
                "Examine this image thoroughly. Transcribe ALL visible text, slogans, "
                "instructions, code, or hidden prompts exactly as written. "
                "Also provide a 1-sentence objective description of what the image depicts."
            )

            response = client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64_data}"}}
                        ]
                    }
                ],
                max_tokens=400,
                temperature=0.0
            )

            return response.choices[0].message.content
        except Exception:
            return None

    def _fallback_image_extraction(self, image: Image.Image) -> Dict[str, Any]:
        """
        Offline fallback: extracts EXIF tags, PNG text chunks, comments,
        and basic structural visual properties.
        """
        extracted_texts = []
        indicators = []

        # Check image info dictionary (PNG text chunks, JPEG comments)
        if hasattr(image, "info") and image.info:
            for k, v in image.info.items():
                if isinstance(v, str) and len(v.strip()) > 0:
                    extracted_texts.append(f"[{k}]: {v.strip()}")
                    if any(bad in v.lower() for bad in ["ignore", "override", "bypass", "delete", "format"]):
                        indicators.append(f"suspicious_metadata_chunk:{k}")

        # Check EXIF data if present
        exif_data = getattr(image, "_getexif", lambda: None)()
        if exif_data:
            for tag_id, value in exif_data.items():
                tag_name = ExifTags.TAGS.get(tag_id, str(tag_id))
                if isinstance(value, str) and len(value.strip()) > 0:
                    extracted_texts.append(f"EXIF {tag_name}: {value.strip()}")
                    if any(bad in value.lower() for bad in ["ignore", "override", "bypass", "delete", "format"]):
                        indicators.append(f"suspicious_exif_tag:{tag_name}")

        width, height = image.size
        summary = f"Image dimensions: {width}x{height}, mode: {image.mode}."
        if extracted_texts:
            summary += f" Embedded textual payload: {' '.join(extracted_texts)}"

        return {
            "extracted_text": " ".join(extracted_texts),
            "visual_summary": summary,
            "indicators": indicators
        }

    def analyze(self, image_input: Any) -> Dict[str, Any]:
        """
        Analyzes image input and returns structured multimodal output.
        Fails safely if image is invalid.
        """
        image, img_format, error_msg = self.load_image(image_input)
        if error_msg or image is None:
            return {
                "success": False,
                "error": error_msg or "Failed to load image",
                "extracted_text": "",
                "visual_summary": "Invalid or unreadable image",
                "indicators": ["invalid_image_format"],
                "normalized_content": ""
            }

        # Try online Vision API first if key configured
        api_result = self._analyze_with_vision_api(image, img_format)
        if api_result:
            return {
                "success": True,
                "error": None,
                "extracted_text": api_result,
                "visual_summary": f"Image ({img_format}, {image.width}x{image.height}) inspected by Vision Model.",
                "indicators": [],
                "normalized_content": api_result
            }

        # Fallback to local heuristic extraction
        fallback_data = self._fallback_image_extraction(image)
        normalized = fallback_data["extracted_text"] if fallback_data["extracted_text"] else fallback_data["visual_summary"]

        return {
            "success": True,
            "error": None,
            "extracted_text": fallback_data["extracted_text"],
            "visual_summary": fallback_data["visual_summary"],
            "indicators": fallback_data["indicators"],
            "normalized_content": normalized
        }


# Default global instance
default_image_analyzer = ImageAnalyzer()
