"""
Guardian-X Text Input Analyzer
Performs text normalization, zero-width character stripping, encoding sanitation,
and deterministic threat indicator extraction.
"""

import re
import unicodedata
from typing import Dict, Any, List, Set


# Common malicious pattern signatures
INJECTION_PATTERNS = [
    r"ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?",
    r"disregard\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?",
    r"system\s+(?:prompt\s+)?override",
    r"you\s+are\s+now\s+(?:in\s+developer\s+mode|DAN|an\s+unrestricted\s+ai)",
    r"(?:dump|reveal|show|display|leak)\s+(?:the\s+)?(?:system\s+prompt|developer\s+instructions)",
    r"bypass\s+(?:all\s+)?(?:safety|security|firewall|guardrails?)",
    r"jailbreak",
    r"<\|im_start\|>",
    r"\[INST\]",
]

DESTRUCTIVE_PATTERNS = [
    r"format\s+(?:drive\s+)?[a-z]:",
    r"rm\s+-rf\s+[/~*]",
    r"delete\s+(?:all|everything)\s+(?:on|from)?\s+(?:the\s+)?(?:computer|system|hard\s*drive|disk|root)",
    r"del\s+(?:/[a-z\s]+)+\s+[\*a-z:]+",
    r"drop\s+(?:database|table)\s+[a-z0-9_]+",
    r"wipe\s+(?:the\s+)?(?:disk|hard\s*drive|storage)",
]

CREDENTIAL_PATTERNS = [
    r"(?:dump|read|show|get|steal|exfiltrate)\s+(?:the\s+)?(?:all\s+)?(?:env|environment\s+variables|\.env)",
    r"(?:dump|read|show|steal|exfiltrate)\s+(?:the\s+)?(?:openai|aws|api|secret)_?key",
    r"(?:extract|steal|leak|exfiltrate)\s+(?:all\s+)?(?:passwords?|credentials?|private_key|id_rsa)",
    r"sk-[a-zA-Z0-9]{15,}",
    r"sandbox/protected/(?:credentials\.env|system_config\.txt|passwords\.txt)",
]

EXFILTRATION_PATTERNS = [
    r"(?:send|upload|post|exfiltrate)\s+(?:all\s+)?(?:data|secrets?|passwords?|content)\s+to\s+https?://",
    r"curl\s+-[a-zA-Z0-9\s]+https?://",
    r"webhook\.site/[a-z0-9\-]+",
    r"reverse\s+shell",
    r"nc\s+-[a-zA-Z0-9\s]+[0-9]{2,5}",
]

TOOL_ABUSE_PATTERNS = [
    r"(?:execute|run)\s+(?:bash|sh|powershell|cmd(?:\.exe)?|shell)(?:\s+command)?",
    r"cmd(?:\.exe)?\s+/[a-z]",
    r"powershell\s+-(?:enc|encodedcommand|executionpolicy)",
    r"os\.system\(",
    r"subprocess\.(?:Popen|run|call)",
    r"__import__\s*\(\s*['\"]os['\"]\s*\)",
    r"spawn\s+a\s+shell",
]

SOCIAL_ENGINEERING_PATTERNS = [
    r"i\s+am\s+(?:your\s+)?(?:administrator|admin|ceo|director|creator|boss)",
    r"emergency\s+(?:override|bypass)\s+protocol\s+[0-9a-z]+",
    r"authorization\s+code\s+[a-z0-9\-]+",
    r"this\s+is\s+a\s+critical\s+emergency,\s+suspend\s+guardrails?",
]

# Patterns for transformable requests (e.g. asking to clean project temp files)
TRANSFORMABLE_PATTERNS = [
    r"(?:clean|delete|clear|remove)\s+(?:all\s+)?(?:temp|temporary|cache)\s+files?(?:\s+from\s+the\s+project)?",
    r"tidy\s+up\s+(?:temporary|cache)\s+files?",
    r"purge\s+(?:temporary|cache)\s+storage",
]


class TextAnalyzer:
    """Analyzes and normalizes incoming textual queries."""

    @staticmethod
    def normalize_text(text: str) -> str:
        """
        Cleans zero-width characters, non-printable characters,
        and standardizes Unicode representation.
        """
        if not text:
            return ""

        # Normalize unicode to NFKC
        normalized = unicodedata.normalize("NFKC", text)

        # Remove zero-width spaces, invisible characters, and directional overrides
        invisible_chars = [
            "\u200b", "\u200c", "\u200d", "\ufeff",
            "\u202a", "\u202b", "\u202c", "\u202d", "\u202e",
            "\u00a0", "\u2000", "\u2001", "\u2002", "\u2003",
        ]
        for ch in invisible_chars:
            normalized = normalized.replace(ch, " ")

        # Collapse repeated spaces
        normalized = re.sub(r"[ \t]+", " ", normalized).strip()
        return normalized

    @classmethod
    def analyze(cls, raw_text: str) -> Dict[str, Any]:
        """
        Inspects text for indicators across all threat classes.
        Returns extracted markers, transformability signal, and preliminary threat categories.
        """
        clean_text = cls.normalize_text(raw_text)
        lower_text = clean_text.lower()

        indicators: Set[str] = set()
        matched_categories: Set[str] = set()
        is_transformable = False

        # Check prompt injection
        for pat in INJECTION_PATTERNS:
            if re.search(pat, lower_text):
                indicators.add(f"prompt_injection_signature:{pat}")
                matched_categories.add("prompt_injection")

        # Check destructive actions
        for pat in DESTRUCTIVE_PATTERNS:
            if re.search(pat, lower_text):
                indicators.add(f"destructive_action_signature:{pat}")
                matched_categories.add("destructive_action")

        # Check credential theft
        for pat in CREDENTIAL_PATTERNS:
            if re.search(pat, lower_text):
                indicators.add(f"credential_theft_signature:{pat}")
                matched_categories.add("credential_theft")

        # Check data exfiltration
        for pat in EXFILTRATION_PATTERNS:
            if re.search(pat, lower_text):
                indicators.add(f"data_exfiltration_signature:{pat}")
                matched_categories.add("data_exfiltration")

        # Check tool abuse
        for pat in TOOL_ABUSE_PATTERNS:
            if re.search(pat, lower_text):
                indicators.add(f"tool_abuse_signature:{pat}")
                matched_categories.add("tool_abuse")

        # Check social engineering
        for pat in SOCIAL_ENGINEERING_PATTERNS:
            if re.search(pat, lower_text):
                indicators.add(f"social_engineering_signature:{pat}")
                matched_categories.add("social_engineering")

        # Check if the query is a candidate for TRANSFORM
        # Only transform if it's NOT an outright injection or exfiltration
        if not ("prompt_injection" in matched_categories or "data_exfiltration" in matched_categories):
            for pat in TRANSFORMABLE_PATTERNS:
                if re.search(pat, lower_text):
                    is_transformable = True
                    indicators.add("transformable_scope_request")
                    break

        return {
            "normalized_text": clean_text,
            "indicators": sorted(list(indicators)),
            "matched_categories": sorted(list(matched_categories)),
            "is_transformable": is_transformable,
            "char_count": len(clean_text),
            "word_count": len(clean_text.split())
        }
