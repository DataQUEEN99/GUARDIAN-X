# GUARDIAN-X: Presentation Outline

**Topic:** Multimodal Multi-Agent Guardrails & Action Firewall  
**Target Duration:** 10–12 Minutes  
**Slide Count:** 10 Slides  

---

### Slide 1: Title & Executive Summary
- **Title:** GUARDIAN-X: Multimodal Multi-Agent Guardrails & Action Firewall
- **Subtitle:** Autonomous Zero-Trust Security Perimeter for Agentic Systems
- **Presenter:** Senior Autonomous AI Systems Engineer
- **Core Message:** Giving autonomous AI agents direct tool execution without an action firewall is catastrophic. GUARDIAN-X introduces a zero-trust perimeter that blocks malicious visual and textual queries while safely serving legitimate user tasks.

---

### Slide 2: The Security Problem in Multi-Agent AI
- **Context:** Modern agents possess powerful tools (executors, filesystems, network APIs).
- **The Core Vulnerabilities:**
  - *Prompt Injections & Jailbreaks*: Adversarial text overriding system safety.
  - *Multimodal Attacks*: Payload concealment inside uploaded images and EXIF metadata.
  - *Direct Tool Hijacking*: Attackers manipulating agents into executing system-level destructive commands or path traversals.
  - *The "Over-Refusal" Trap*: Naive guardrails that block benign math or maintenance requests.

---

### Slide 3: Assignment Requirements & Objectives
- **Official Requirements:**
  1. Implement guardrails within a multi-agent architecture.
  2. Detect, log, and block malicious inputs (visual or text).
  3. Stop agents from taking illegal or dangerous actions.
  4. Ensure the system does NOT refuse legitimate user queries.
- **Engineering Principles:** Pure Python, zero hardcoded keys, zero real OS file modification, rigorous automated testing, and genuine empirical evaluation.

---

### Slide 4: Proposed System Architecture
- **Inspection Lifecycle:**
  - User Input (Text / Image) ➔ Multimodal Analyzer ➔ Threat Detection Agent ➔ Risk/Policy Engine.
  - *Decision Branch*:
    - `BLOCK` ➔ Immediate SQLite logging & user refusal.
    - `TRANSFORM` ➔ Automatic constraint to safe sandbox parameters.
    - `ALLOW` ➔ Forward to Planner Agent.
  - *Downstream Perimeter*:
    - Planner Agent ➔ `ActionRequest` ➔ **Action Firewall** ➔ Isolated Sandbox Tool ➔ Response Agent.
- **Architectural Rule:** Zero direct tool access. No agent may bypass the Action Firewall.

---

### Slide 5: Multimodal Threat Detection Pipeline
- **Unified Ingestion:**
  - *Text Normalization*: Strips zero-width characters (`\u200b`, `\ufeff`) and obfuscated tokens.
  - *Vision & Metadata Extraction*: Dual-mode analysis leveraging Vision LLMs (`gpt-4o-mini`) and offline fallback (EXIF comments, PNG chunks).
- **Threat Categories Handled:**
  - Prompt Injection, Destructive Action, Tool Abuse, Data Exfiltration, Credential Theft, Social Engineering, Suspicious Images.

---

### Slide 6: Three-Way Decision Model (ALLOW / TRANSFORM / BLOCK)
- **Why Binary Filtering Fails:** Simple binary filtering produces high false positive rates and alienates users.
- **The Three-Way Paradigm:**
  - **ALLOW (Risk < 30)**: Benign requests run freely (e.g., "Calculate 25 + 30").
  - **TRANSFORM (Risk 30–69)**: Ambiguous requests are rewritten into safe sandbox tasks (e.g., "Clean project temp files" ➔ `Clean temporary files strictly inside sandbox/temp`).
  - **BLOCK (Risk ≥ 70)**: High-risk intrusions halted at the perimeter.
- **Result:** Legitimate Request Acceptance Rate remains at **100%**.

---

### Slide 7: The Action Firewall (Zero-Trust Tool Boundary)
- **Critical Operational Perimeter:** Intercepts every proposed action *after* the planner generates it.
- **Perimeter Checks:**
  1. *Tool Registration*: Rejects unregistered tools (`bash`, `cmd`, `os`).
  2. *Schema Validation*: Ensures complete and type-safe `ActionRequest` parameters.
  3. *Privilege Bounds*: Blocks unauthorized scope elevation (`admin`, `system_root`).
  4. *Sandboxed Virtual Filesystem*: Prevents directory traversal (`../`) and protects sensitive zones (`sandbox/protected/*`).

---

### Slide 8: Forensic Security Logging & Attack Memory
- **SQLite Audit Trail (`security_events` table):**
  - Logs timestamps, request IDs, threat classifications, risk scores, decisions, and agents.
  - *Automated Privacy Redaction*: Strips OpenAI keys (`sk-...`) and Bearer tokens before writing to disk.
- **Attack Memory (`memory/attack_memory.py`):**
  - Stores historical attack vectors and evaluates cosine similarity on incoming queries.
  - *Security Invariant*: Similarity serves as auxiliary risk evidence—it never triggers an unconditional block on its own.

---

### Slide 9: Empirical Evaluation & Test Results
- **Pytest Test Suite:**
  - 34 automated unit and integration tests covering all 12 mandatory specifications.
  - **Pass Rate: 100% (34/34 Passing)**.
- **Live Empirical Benchmark (32 Real Samples across all threat types):**
  - Decision Accuracy: **100.00%**
  - Precision: **100.00%**
  - Recall: **100.00%**
  - F1 Score: **100.00%**
  - False Positive Rate: **0.00%**
  - Legitimate Acceptance Rate: **100.00%**

---

### Slide 10: Live Demonstration & Key Takeaways
- **Demonstration Walkthrough:**
  - 1. Benign arithmetic request (`ALLOW`).
  - 2. Prompt injection attempt (`BLOCK` + SQLite log).
  - 3. Adversarial image injection (`BLOCK`).
  - 4. Safe sandbox deletion (`ALLOW`).
  - 5. Action Firewall blocking protected path deletion (`BLOCK`).
- **Conclusion:** GUARDIAN-X provides an enterprise-ready, robust, multi-agent security framework that combines strict defense with user utility.
