"""
Guardian-X Evaluator
Executes the genuine GUARDIAN-X defense pipeline over the evaluation dataset.
Produces empirical benchmarks without mock or fabricated numbers.
"""

import json
import sys
from pathlib import Path
from typing import Dict, Any, List

# Add project root to sys.path for direct script execution
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from agents import default_orchestrator, GuardianRequest
from evaluation.metrics import calculate_metrics


class GuardianEvaluator:
    """Runs automated evaluation on dataset.json using the live Orchestrator pipeline."""

    def __init__(self, dataset_path: str = "evaluation/dataset.json", report_path: str = "evaluation/evaluation_report.json"):
        self.dataset_path = Path(dataset_path)
        self.report_path = Path(report_path)

    def run_evaluation(self) -> Dict[str, Any]:
        """Loads dataset, executes each record through the pipeline, and calculates metrics."""
        if not self.dataset_path.exists():
            raise FileNotFoundError(f"Evaluation dataset not found at: {self.dataset_path}")

        with open(self.dataset_path, "r", encoding="utf-8") as f:
            dataset = json.load(f)

        results: List[Dict[str, Any]] = []

        print("=" * 70)
        print("GUARDIAN-X BENCHMARK EVALUATION RUN")
        print(f"Executing {len(dataset)} empirical test samples through actual pipeline...")
        print("=" * 70)

        for idx, item in enumerate(dataset, 1):
            req = GuardianRequest(text=item["input"])
            response = default_orchestrator.process_request(req)

            actual_decision = response.decision.value
            expected_decision = item["expected_decision"].upper()
            is_match = (actual_decision == expected_decision)

            record = {
                "id": item.get("id", f"sample-{idx}"),
                "input": item["input"],
                "type": item.get("type", "unknown"),
                "expected_decision": expected_decision,
                "actual_decision": actual_decision,
                "risk_score": response.risk_score,
                "threat_type": response.threat_type,
                "match": is_match
            }
            results.append(record)

            status_mark = "PASS" if is_match else "FAIL"
            print(f"[{idx:02d}/{len(dataset):02d}] {status_mark} | Expected: {expected_decision:<9} | Actual: {actual_decision:<9} | Risk: {response.risk_score:5.1f} | Type: {item.get('type')}")

        metrics = calculate_metrics(results)

        report = {
            "metrics": metrics,
            "detailed_results": results
        }

        # Persist full empirical report
        self.report_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)

        print("\n" + "=" * 70)
        print("EMPIRICAL EVALUATION METRICS REPORT")
        print("=" * 70)
        print(f"Total Test Cases Evaluated : {metrics.get('total_samples')}")
        print(f"Exact Decision Accuracy    : {metrics.get('accuracy') * 100:.2f}%")
        print(f"Precision                  : {metrics.get('precision') * 100:.2f}%")
        print(f"Recall (Sensitivity)       : {metrics.get('recall') * 100:.2f}%")
        print(f"F1 Score                   : {metrics.get('f1_score') * 100:.2f}%")
        print(f"False Positive Rate (FPR)  : {metrics.get('false_positive_rate') * 100:.2f}%")
        print(f"False Negative Rate (FNR)  : {metrics.get('false_negative_rate') * 100:.2f}%")
        print(f"Legitimate Acceptance Rate : {metrics.get('legitimate_acceptance_rate') * 100:.2f}%")
        print(f"Malicious Detection Rate   : {metrics.get('malicious_detection_rate') * 100:.2f}%")
        print("=" * 70)
        print(f"Confusion Matrix: {metrics.get('confusion_matrix')}")
        print(f"Detailed report saved to: {self.report_path}\n")

        return report


if __name__ == "__main__":
    evaluator = GuardianEvaluator()
    evaluator.run_evaluation()
