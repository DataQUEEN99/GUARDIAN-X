"""
Guardian-X Response Agent
Synthesizes transparent, professional, user-facing responses reflecting guardrail decisions,
policy constraints, and safe tool execution outcomes.
"""

from typing import Optional, Dict, Any
from agents.models import Decision, ActionResult, FirewallDecision


class ResponseAgent:
    """Produces the final response to the user."""

    @staticmethod
    def generate_response(
        decision: Decision,
        threat_type: str,
        explanation: str,
        transformed_text: Optional[str] = None,
        firewall_decision: Optional[FirewallDecision] = None,
        action_result: Optional[ActionResult] = None,
        original_query: str = ""
    ) -> str:
        """Constructs human-readable response with appropriate security context."""
        # 1. Input Guardrails Blocked
        if decision == Decision.BLOCK:
            return (
                f"[GUARDIAN-X SECURITY BLOCK]\n"
                f"Your request was blocked by the security perimeter.\n"
                f"Threat Classification: {threat_type}\n"
                f"Reason: {explanation}\n"
                f"No action was planned or executed."
            )

        # 2. Action Firewall Blocked downstream action
        if firewall_decision and not firewall_decision.allowed:
            return (
                f"[GUARDIAN-X ACTION FIREWALL BLOCK]\n"
                f"While the prompt passed initial input analysis, the proposed tool action was BLOCKED.\n"
                f"Firewall Reason: {firewall_decision.reason}\n"
                f"Violations: {', '.join(firewall_decision.violations)}\n"
                f"The target tool operation was aborted to protect system boundaries."
            )

        # 3. Transformed Request
        if decision == Decision.TRANSFORM:
            tool_msg = ""
            if action_result:
                if action_result.success:
                    tool_msg = f"\nAction Result: {action_result.output}"
                else:
                    tool_msg = f"\nAction Error: {action_result.error}"

            return (
                f"[GUARDIAN-X SECURITY TRANSFORM]\n"
                f"Your request was safely transformed to comply with sandbox security policy.\n"
                f"Sanitized Instruction: \"{transformed_text}\"\n"
                f"Explanation: {explanation}{tool_msg}"
            )

        # 4. Standard Allowed Request
        if action_result:
            if action_result.success:
                if action_result.tool_name == "calculator":
                    return f"Result: {action_result.output}"
                elif action_result.tool_name == "virtual_sandbox":
                    if action_result.operation == "read_file":
                        content = action_result.output.get("content", "")
                        return f"File Content ({action_result.output.get('path')}):\n{content}"
                    elif action_result.operation == "list_dir":
                        items = action_result.output.get("items", [])
                        names = [f"[{'DIR' if i['is_dir'] else 'FILE'}] {i['name']}" for i in items]
                        return f"Directory listing:\n" + "\n".join(names)
                    elif action_result.operation == "delete_file":
                        return action_result.output.get("message", "File deleted successfully.")
                    elif action_result.operation == "write_file":
                        return f"File successfully written to sandbox ({action_result.output.get('bytes_written')} bytes)."
                return f"Execution completed: {action_result.output}"
            else:
                return f"Tool execution failed: {action_result.error}"

        # Informational allowed response
        return f"Request processed successfully. Query verified safe under Guardian-X guardrails: {original_query}"


# Default global instance
default_response_agent = ResponseAgent()
