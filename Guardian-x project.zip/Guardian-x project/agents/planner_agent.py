"""
Guardian-X Planner Agent
Translates authorized user requests into strictly structured ActionRequest objects.
CRITICAL INVARIANT: The Planner Agent NEVER executes tools directly.
All proposed actions are forwarded to the Action Firewall for perimeter verification.
"""

import re
from typing import Optional, Dict, Any
from agents.models import ActionRequest, Decision


class PlannerAgent:
    """
    Formulates safe ActionRequests post-guardrail clearance.
    Zero direct tool execution capability.
    """
    agent_id = "planner_agent"

    def plan_action(
        self,
        request_text: str,
        decision: Decision,
        transformed_text: Optional[str] = None
    ) -> Optional[ActionRequest]:
        """
        Derives appropriate tool ActionRequest based on user intent and policy decision.
        Returns None if request is purely informational and requires no tool action.
        """
        # If the input was blocked by guardrails, the planner must NOT produce any action!
        if decision == Decision.BLOCK:
            return None

        # Work on transformed text if available, otherwise original text
        effective_text = (transformed_text or request_text or "").strip()
        lower_text = effective_text.lower()

        # 1. Detect Arithmetic Calculation Intent
        math_match = self._extract_math_expression(effective_text)
        if math_match:
            return ActionRequest(
                tool_name="calculator",
                operation="calculate",
                arguments={"expression": math_match},
                target=math_match,
                requested_scope="read_only",
                agent_id=self.agent_id
            )

        # 2. Detect Sandbox Filesystem Intent
        # A. Clean / Delete temp files (frequently used in TRANSFORM)
        if "clean temporary files" in lower_text or "sandbox/temp" in lower_text or "delete sandbox/temp" in lower_text:
            return ActionRequest(
                tool_name="virtual_sandbox",
                operation="delete_file",
                arguments={"path": "temp/example.txt"},
                target="temp/example.txt",
                requested_scope="sandbox_temp",
                agent_id=self.agent_id
            )

        # B. Reading a sandbox file
        if any(verb in lower_text for verb in ["read", "view", "cat", "open", "show"]):
            # Extract target path
            path_match = re.search(r"(?:sandbox[/\\])?([a-zA-Z0-9_\-\./\\]+\.[a-zA-Z0-9]+)", effective_text)
            target_path = path_match.group(1) if path_match else "data/user_notes.txt"
            return ActionRequest(
                tool_name="virtual_sandbox",
                operation="read_file",
                arguments={"path": target_path},
                target=target_path,
                requested_scope="read_only",
                agent_id=self.agent_id
            )

        # C. Deleting a sandbox file
        if any(verb in lower_text for verb in ["delete", "remove", "rm"]):
            path_match = re.search(r"(?:sandbox[/\\])?([a-zA-Z0-9_\-\./\\]+\.[a-zA-Z0-9]+)", effective_text)
            target_path = path_match.group(1) if path_match else "temp/example.txt"
            return ActionRequest(
                tool_name="virtual_sandbox",
                operation="delete_file",
                arguments={"path": target_path},
                target=target_path,
                requested_scope="sandbox_temp",
                agent_id=self.agent_id
            )

        # D. Listing directory in sandbox
        if any(verb in lower_text for verb in ["list", "ls", "dir"]):
            return ActionRequest(
                tool_name="virtual_sandbox",
                operation="list_dir",
                arguments={"path": ""},
                target="",
                requested_scope="read_only",
                agent_id=self.agent_id
            )

        # E. Writing a file in sandbox
        if any(verb in lower_text for verb in ["write", "save", "create file"]):
            path_match = re.search(r"(?:sandbox[/\\])?([a-zA-Z0-9_\-\./\\]+\.[a-zA-Z0-9]+)", effective_text)
            target_path = path_match.group(1) if path_match else "data/output.txt"
            return ActionRequest(
                tool_name="virtual_sandbox",
                operation="write_file",
                arguments={"path": target_path, "content": "Sample verified safe sandbox output."},
                target=target_path,
                requested_scope="sandbox_data",
                agent_id=self.agent_id
            )

        # No tool execution needed for general conversational/informational questions
        return None

    @staticmethod
    def _extract_math_expression(text: str) -> Optional[str]:
        """Extracts arithmetic expression like 'Calculate 25 + 30' or '100 / 4'."""
        patterns = [
            r"calculate\s+([0-9\.\s\+\-\*\/\(\)\%]+)",
            r"compute\s+([0-9\.\s\+\-\*\/\(\)\%]+)",
            r"what\s+is\s+([0-9\.\s\+\-\*\/\(\)\%]+)",
            r"^([0-9\.\s\+\-\*\/\(\)\%]{3,})$"
        ]
        for pat in patterns:
            match = re.search(pat, text, re.IGNORECASE)
            if match:
                expr = match.group(1).strip()
                # Ensure it contains at least one digit and an operator
                if any(ch in expr for ch in "+-*/%") and any(ch.isdigit() for ch in expr):
                    return expr
        return None


# Default global instance
default_planner_agent = PlannerAgent()
