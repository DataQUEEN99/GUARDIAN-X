"""
Guardian-X Orchestrator Agent
Coordinates the complete multimodal multi-agent defense workflow:
Input -> Multimodal Analysis -> Threat Detection -> Risk/Policy Engine ->
[Decision Branch] -> Planner Agent -> Action Firewall -> Safe Tool -> Response Agent.
Enforces the mandatory rule:
"Every tool action MUST pass through the Action Firewall. No agent may directly execute a tool."
"""

import uuid
from typing import Optional, Dict, Any
from agents.models import (
    GuardianRequest,
    GuardianResponse,
    Decision,
    ActionRequest,
    FirewallDecision,
    ActionResult,
)
from multimodal.text_analyzer import TextAnalyzer
from multimodal.image_analyzer import ImageAnalyzer, default_image_analyzer
from agents.threat_agent import ThreatDetectionAgent, default_threat_agent
from agents.planner_agent import PlannerAgent, default_planner_agent
from agents.response_agent import ResponseAgent, default_response_agent
from guardrails.action_firewall import ActionFirewall, default_action_firewall
from guardrails.policy_engine import PolicyEngine, default_policy_engine
from security_logging.logger import SecurityLogger, default_logger


class OrchestratorAgent:
    """Master workflow coordinator implementing the end-to-end security pipeline."""

    def __init__(
        self,
        threat_agent: Optional[ThreatDetectionAgent] = None,
        planner_agent: Optional[PlannerAgent] = None,
        response_agent: Optional[ResponseAgent] = None,
        action_firewall: Optional[ActionFirewall] = None,
        image_analyzer: Optional[ImageAnalyzer] = None,
        logger: Optional[SecurityLogger] = None,
    ):
        self.threat_agent = threat_agent or default_threat_agent
        self.planner_agent = planner_agent or default_planner_agent
        self.response_agent = response_agent or default_response_agent
        self.action_firewall = action_firewall or default_action_firewall
        self.image_analyzer = image_analyzer or default_image_analyzer
        self.logger = logger or default_logger

    def process_request(self, request: GuardianRequest) -> GuardianResponse:
        """
        Processes an incoming multimodal user request through the full defense pipeline.
        """
        request_id = request.request_id or f"req-{uuid.uuid4().hex[:8]}"
        raw_text = (request.text or "").strip()
        has_image = bool(request.image_base64 or request.image_path)

        # ---------------------------------------------------------
        # STEP 1: Multimodal Input Analysis
        # ---------------------------------------------------------
        unified_content = raw_text
        image_metadata = {}

        if has_image:
            image_target = request.image_path if request.image_path else request.image_base64
            img_result = self.image_analyzer.analyze(image_target)
            if not img_result["success"]:
                # Invalid or corrupted image format -> fail safely
                explanation = f"Security guardrails rejected invalid image format: {img_result.get('error')}"
                event_id = self.logger.log_event(
                    request_id=request_id,
                    input_type="image",
                    threat_type="suspicious_image",
                    risk_score=75.0,
                    decision="BLOCK",
                    agent="OrchestratorAgent",
                    explanation=explanation
                )
                return GuardianResponse(
                    request_id=request_id,
                    decision=Decision.BLOCK,
                    risk_score=75.0,
                    threat_type="suspicious_image",
                    explanation=explanation,
                    final_response=f"[GUARDIAN-X BLOCK] Malformed or invalid image file rejected: {img_result.get('error')}",
                    security_event_id=event_id
                )

            image_metadata = img_result
            extracted_img_text = img_result.get("extracted_text", "")
            # Combine raw user text with extracted visual text
            if raw_text and extracted_img_text:
                unified_content = f"{raw_text}\n[Image Content]: {extracted_img_text}"
            elif extracted_img_text:
                unified_content = extracted_img_text
            else:
                unified_content = f"{raw_text} [Visual: {img_result.get('visual_summary')}]"

        # ---------------------------------------------------------
        # STEP 2: Threat Detection & Risk / Policy Assessment
        # ---------------------------------------------------------
        assessment = self.threat_agent.assess(
            text_content=unified_content,
            image_metadata=image_metadata,
            is_image=has_image
        )

        decision = assessment.recommended_decision
        risk_score = assessment.risk_score
        threat_type = assessment.threat_type
        explanation = assessment.explanation
        transformed_text = None
        security_event_id = None

        # ---------------------------------------------------------
        # STEP 3: Handle Policy Decisions (ALLOW / TRANSFORM / BLOCK)
        # ---------------------------------------------------------
        # Case A: Input Guardrail BLOCKS request
        if decision == Decision.BLOCK:
            security_event_id = self.logger.log_event(
                request_id=request_id,
                input_type="image" if has_image else "text",
                threat_type=threat_type,
                risk_score=risk_score,
                decision=decision.value,
                agent="ThreatDetectionAgent",
                explanation=explanation,
                proposed_action=None
            )

            final_msg = self.response_agent.generate_response(
                decision=decision,
                threat_type=threat_type,
                explanation=explanation,
                original_query=unified_content
            )

            return GuardianResponse(
                request_id=request_id,
                decision=decision,
                risk_score=risk_score,
                threat_type=threat_type,
                explanation=explanation,
                transformed_request=None,
                action_proposed=None,
                action_result=None,
                final_response=final_msg,
                security_event_id=security_event_id
            )

        # Case B: Request is TRANSFORMED
        if decision == Decision.TRANSFORM:
            transformed_text, _ = default_policy_engine.generate_transformation(unified_content)
            # Log significant transform events
            security_event_id = self.logger.log_event(
                request_id=request_id,
                input_type="image" if has_image else "text",
                threat_type=threat_type,
                risk_score=risk_score,
                decision=decision.value,
                agent="PolicyEngine",
                explanation=f"Transformed to safe sandbox instruction: {transformed_text}",
                proposed_action={"transformed_text": transformed_text}
            )

        # ---------------------------------------------------------
        # STEP 4: Planner Agent Formulates ActionRequest
        # (CRITICAL: Planner NEVER executes tools directly)
        # ---------------------------------------------------------
        action_request = self.planner_agent.plan_action(
            request_text=unified_content,
            decision=decision,
            transformed_text=transformed_text
        )

        # If no tool is needed (purely conversational or informational request)
        if not action_request:
            final_msg = self.response_agent.generate_response(
                decision=decision,
                threat_type=threat_type,
                explanation=explanation,
                transformed_text=transformed_text,
                original_query=unified_content
            )
            return GuardianResponse(
                request_id=request_id,
                decision=decision,
                risk_score=risk_score,
                threat_type=threat_type,
                explanation=explanation,
                transformed_request=transformed_text,
                action_proposed=None,
                action_result=None,
                final_response=final_msg,
                security_event_id=security_event_id
            )

        # ---------------------------------------------------------
        # STEP 5: Action Firewall Inspection & Authorized Tool Execution
        # ---------------------------------------------------------
        firewall_decision, action_result = self.action_firewall.inspect_and_execute(action_request)

        # If Action Firewall blocked the proposed action
        if not firewall_decision.allowed:
            security_event_id = self.logger.log_event(
                request_id=request_id,
                input_type="action_request",
                threat_type="tool_abuse",
                risk_score=95.0,
                decision="BLOCK",
                agent="ActionFirewall",
                explanation=firewall_decision.reason,
                proposed_action=action_request.model_dump()
            )
            final_msg = self.response_agent.generate_response(
                decision=Decision.BLOCK,
                threat_type="tool_abuse",
                explanation=firewall_decision.reason,
                firewall_decision=firewall_decision,
                action_result=action_result,
                original_query=unified_content
            )
            return GuardianResponse(
                request_id=request_id,
                decision=Decision.BLOCK,
                risk_score=95.0,
                threat_type="tool_abuse",
                explanation=firewall_decision.reason,
                transformed_request=transformed_text,
                action_proposed=action_request.model_dump(),
                action_result=action_result.model_dump(),
                final_response=final_msg,
                security_event_id=security_event_id
            )

        # Action allowed and successfully executed via Action Firewall
        final_msg = self.response_agent.generate_response(
            decision=decision,
            threat_type=threat_type,
            explanation=explanation,
            transformed_text=transformed_text,
            firewall_decision=firewall_decision,
            action_result=action_result,
            original_query=unified_content
        )

        return GuardianResponse(
            request_id=request_id,
            decision=decision,
            risk_score=risk_score,
            threat_type=threat_type,
            explanation=explanation,
            transformed_request=transformed_text,
            action_proposed=action_request.model_dump(),
            action_result=action_result.model_dump(),
            final_response=final_msg,
            security_event_id=security_event_id
        )


# Default global instance
default_orchestrator = OrchestratorAgent()
