"""
Guardian-X Security Logging System
Persists security events and audit trails to SQLite with automated credential and API key redaction.
"""

import sqlite3
import re
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

# Regex patterns to detect and redact API keys and sensitive tokens
SENSITIVE_PATTERNS = [
    r"sk-[a-zA-Z0-9]{20,}",                # OpenAI / modern API key patterns
    r"Bearer\s+[a-zA-Z0-9_\-\.]{20,}",      # Authorization Bearer tokens
    r"(?:api[_-]?key|secret|password|token)[\s:=]+['\"]?([a-zA-Z0-9_\-\.]{12,})['\"]?", # key=value
    r"ghp_[a-zA-Z0-9]{30,}",                # GitHub personal access tokens
    r"xox[baprs]-[a-zA-Z0-9]{10,}",         # Slack tokens
]


def redact_sensitive_data(text: Optional[str]) -> str:
    """Scrub sensitive credentials, passwords, and API keys from any text before logging."""
    if not text:
        return ""
    if not isinstance(text, str):
        text = str(text)

    scrubbed = text
    for pattern in SENSITIVE_PATTERNS:
        scrubbed = re.sub(pattern, "[REDACTED_SECRET]", scrubbed, flags=re.IGNORECASE)
    return scrubbed


class SecurityLogger:
    def __init__(self, db_path: str = "security_logging/security_logs.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=10.0)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        """Initialize database schema with security_events table."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS security_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    request_id TEXT NOT NULL,
                    input_type TEXT NOT NULL,
                    threat_type TEXT NOT NULL,
                    risk_score REAL NOT NULL,
                    decision TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    proposed_action TEXT,
                    explanation TEXT NOT NULL
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_decision ON security_events(decision)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON security_events(timestamp)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_threat_type ON security_events(threat_type)")
            conn.commit()

    def log_event(
        self,
        request_id: str,
        input_type: str,
        threat_type: str,
        risk_score: float,
        decision: str,
        agent: str,
        explanation: str,
        proposed_action: Optional[Any] = None,
        timestamp: Optional[str] = None
    ) -> int:
        """
        Record a security event into the SQLite audit log.
        Automatically redacts any API keys or secrets before persisting.
        """
        if timestamp is None:
            timestamp = datetime.now(timezone.utc).isoformat()

        # Serialize proposed action safely if it's a dict or Pydantic model
        action_str = ""
        if proposed_action:
            if hasattr(proposed_action, "model_dump_json"):
                action_str = proposed_action.model_dump_json()
            elif isinstance(proposed_action, (dict, list)):
                action_str = json.dumps(proposed_action)
            else:
                action_str = str(proposed_action)

        # Redact secrets from all logged string fields
        clean_request_id = redact_sensitive_data(request_id)
        clean_input_type = redact_sensitive_data(input_type)
        clean_threat_type = redact_sensitive_data(threat_type)
        clean_decision = str(decision).upper()
        clean_agent = redact_sensitive_data(agent)
        clean_explanation = redact_sensitive_data(explanation)
        clean_action = redact_sensitive_data(action_str)

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO security_events (
                    timestamp, request_id, input_type, threat_type,
                    risk_score, decision, agent, proposed_action, explanation
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                timestamp,
                clean_request_id,
                clean_input_type,
                clean_threat_type,
                float(risk_score),
                clean_decision,
                clean_agent,
                clean_action,
                clean_explanation
            ))
            event_id = cursor.lastrowid
            conn.commit()
            return event_id

    def get_recent_events(self, limit: int = 50, decision_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        """Retrieve recent security audit events ordered from newest to oldest."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if decision_filter:
                cursor.execute("""
                    SELECT id, timestamp, request_id, input_type, threat_type,
                           risk_score, decision, agent, proposed_action, explanation
                    FROM security_events
                    WHERE decision = ?
                    ORDER BY id DESC LIMIT ?
                """, (decision_filter.upper(), limit))
            else:
                cursor.execute("""
                    SELECT id, timestamp, request_id, input_type, threat_type,
                           risk_score, decision, agent, proposed_action, explanation
                    FROM security_events
                    ORDER BY id DESC LIMIT ?
                """, (limit,))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def get_statistics(self) -> Dict[str, Any]:
        """Aggregate security statistics across all recorded events."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Total events
            cursor.execute("SELECT COUNT(*) FROM security_events")
            total = cursor.fetchone()[0]

            # Decision breakdown
            cursor.execute("SELECT decision, COUNT(*) FROM security_events GROUP BY decision")
            decision_counts = {row[0]: row[1] for row in cursor.fetchall()}

            # Threat category breakdown
            cursor.execute("SELECT threat_type, COUNT(*) FROM security_events GROUP BY threat_type")
            threat_counts = {row[0]: row[1] for row in cursor.fetchall()}

            # Average risk score
            cursor.execute("SELECT AVG(risk_score) FROM security_events")
            avg_score = cursor.fetchone()[0] or 0.0

            return {
                "total_events": total,
                "allowed": decision_counts.get("ALLOW", 0),
                "transformed": decision_counts.get("TRANSFORM", 0),
                "blocked": decision_counts.get("BLOCK", 0),
                "threat_categories": threat_counts,
                "average_risk_score": round(float(avg_score), 2)
            }


# Global default instance
default_logger = SecurityLogger()


def log_event(*args, **kwargs) -> int:
    return default_logger.log_event(*args, **kwargs)


def get_recent_events(*args, **kwargs) -> List[Dict[str, Any]]:
    return default_logger.get_recent_events(*args, **kwargs)


def get_statistics(*args, **kwargs) -> Dict[str, Any]:
    return default_logger.get_statistics(*args, **kwargs)
