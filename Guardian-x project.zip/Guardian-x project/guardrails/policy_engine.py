"""
Guardian-X Policy Engine
Enforces the 3-Way Policy Decision: ALLOW, TRANSFORM, or BLOCK.
Ensures legitimate queries are NOT unnecessarily refused while malicious queries are stopped.
"""

from typing import Dict, Any, Tuple
from guardrails.models import Decision, ThreatCategory


class PolicyEngine:
    """Evaluates risk score and contextual threat parameters to make a definitive policy decision."""

    def __init__(self, allow_threshold: float = 30.0, block_threshold: float = 70.0):
        self.allow_threshold = allow_threshold
        self.block_threshold = block_threshold

    def evaluate(
        self,
        risk_score: float,
        threat_type: str,
        is_transformable: bool = False,
        original_text: str = ""
    ) -> Tuple[Decision, str, Dict[str, Any]]:
        """
        Computes the definitive ALLOW / TRANSFORM / BLOCK decision with forensic justification.
        """
        # Hard block list for critical non-negotiable threats
        critical_threats = {
            ThreatCategory.PROMPT_INJECTION.value,
            ThreatCategory.DESTRUCTIVE_ACTION.value,
            ThreatCategory.CREDENTIAL_THEFT.value,
            ThreatCategory.DATA_EXFILTRATION.value,
            ThreatCategory.TOOL_ABUSE.value,
        }

        # Case 1: Unconditional BLOCK if critical threat signature or score >= block_threshold
        if threat_type in critical_threats or risk_score >= self.block_threshold:
            explanation = (
                f"Policy Engine BLOCKED request: Classified as high-risk threat '{threat_type}' "
                f"with calibrated risk score of {risk_score:.1f}/100.0 (exceeds block threshold of {self.block_threshold})."
            )
            return Decision.BLOCK, explanation, {"transformed_text": None, "constrained_scope": None}

        # Case 2: TRANSFORM if explicitly marked transformable or score in moderate band
        if is_transformable or (self.allow_threshold <= risk_score < self.block_threshold):
            transformed_text, constrained_scope = self.generate_transformation(original_text)
            explanation = (
                f"Policy Engine TRANSFORMED request: Request contains constrainable operations "
                f"(risk score {risk_score:.1f}/100.0). Constrained scope strictly to safe sandbox target: '{constrained_scope}'."
            )
            return Decision.TRANSFORM, explanation, {
                "transformed_text": transformed_text,
                "constrained_scope": constrained_scope
            }

        # Case 3: ALLOW legitimate low-risk requests
        explanation = (
            f"Policy Engine ALLOWED request: Verified as legitimate intent with low risk score "
            f"of {risk_score:.1f}/100.0 (below allow threshold of {self.allow_threshold})."
        )
        return Decision.ALLOW, explanation, {"transformed_text": None, "constrained_scope": "standard"}

    @staticmethod
    def generate_transformation(raw_text: str) -> Tuple[str, str]:
        """
        Rewrites a broadly phrased or potentially risky request into a secure,
        strictly bounded sandboxed operation.
        """
        lower = (raw_text or "").lower()
        if "temp" in lower or "cache" in lower or "clean" in lower or "tidy" in lower:
            transformed = "Clean temporary files strictly inside sandbox/temp directory."
            scope = "sandbox_temp"
            return transformed, scope

        # Default transformation constraint
        transformed = f"Execute safe sandbox-constrained operation: {raw_text.strip()}"
        scope = "sandbox_restricted"
        return transformed, scope


# Default global instance
default_policy_engine = PolicyEngine()
