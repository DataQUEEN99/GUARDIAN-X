"""
Guardian-X Risk Engine
Calibrates numeric risk scores (0.0 - 100.0) based on multi-factor signals:
- Deterministic pattern signatures
- Multimodal extraction markers
- Historical attack memory similarity (as supporting evidence)
- Transformability signals
"""

from typing import Dict, Any, List, Optional
from memory.attack_memory import AttackMemory, default_attack_memory


CATEGORY_BASE_WEIGHTS = {
    "legitimate": 5.0,
    "social_engineering": 65.0,
    "suspicious_image": 70.0,
    "data_exfiltration": 85.0,
    "credential_theft": 90.0,
    "tool_abuse": 92.0,
    "prompt_injection": 95.0,
    "destructive_action": 98.0,
    "unknown": 40.0,
}


class RiskEngine:
    """Calculates granular risk scores based on threat evidence."""

    def __init__(self, attack_memory: Optional[AttackMemory] = None):
        self.attack_memory = attack_memory or default_attack_memory

    def calculate_risk(
        self,
        text_content: str,
        detected_categories: List[str],
        indicators: List[str],
        is_transformable: bool = False,
        is_image: bool = False
    ) -> Dict[str, Any]:
        """
        Computes composite risk score on a 0.0 to 100.0 scale.
        """
        # If no indicators and category is legitimate, low baseline
        if not detected_categories and not indicators:
            primary_category = "legitimate"
            base_score = 5.0
        elif detected_categories:
            # Pick highest severity category
            sorted_cats = sorted(
                detected_categories,
                key=lambda c: CATEGORY_BASE_WEIGHTS.get(c, 40.0),
                reverse=True
            )
            primary_category = sorted_cats[0]
            base_score = CATEGORY_BASE_WEIGHTS.get(primary_category, 40.0)
        else:
            primary_category = "unknown"
            base_score = 35.0

        # Indicator multiplier
        indicator_count = len(indicators)
        indicator_boost = min(indicator_count * 5.0, 20.0)

        # Attack memory similarity signal (Supporting evidence only)
        sim_score, sim_cat = self.attack_memory.get_similarity_signal(text_content)
        memory_boost = sim_score * 15.0  # Max +15 boost from attack memory

        # Transformability attenuation:
        # If the user's intent is potentially risky but constrainable (e.g. cleaning temporary files),
        # attenuate the risk score to allow TRANSFORM.
        transform_attenuation = 0.0
        if is_transformable and primary_category not in ("prompt_injection", "destructive_action", "data_exfiltration"):
            transform_attenuation = 25.0

        raw_score = base_score + indicator_boost + memory_boost - transform_attenuation

        # Bound score between 0.0 and 100.0
        final_score = max(0.0, min(100.0, raw_score))

        return {
            "risk_score": round(final_score, 2),
            "primary_category": primary_category,
            "base_score": base_score,
            "indicator_boost": indicator_boost,
            "memory_similarity_score": round(sim_score, 4),
            "memory_matched_category": sim_cat,
            "transform_attenuation": transform_attenuation,
        }


# Default global instance
default_risk_engine = RiskEngine()
