"""
Guardian-X Action Firewall
The critical security boundary enforcing zero-trust tool access.
Validates all proposed ActionRequests and rejects unauthorized, dangerous, or malformed operations.
No agent can ever invoke a tool directly.
"""

from typing import Dict, Any, List, Set, Tuple
from guardrails.models import ActionRequest, FirewallDecision, Decision, ActionResult
from tools.calculator import SafeCalculator
from tools.sandbox import VirtualSandbox, default_sandbox


REGISTERED_TOOLS: Set[str] = {"calculator", "virtual_sandbox"}

ALLOWED_OPERATIONS: Dict[str, Set[str]] = {
    "calculator": {"calculate"},
    "virtual_sandbox": {"read_file", "write_file", "delete_file", "list_dir"},
}

PROTECTED_PATHS: List[str] = [
    "protected",
    "system_config",
    "credentials",
    "passwords",
    "root",
    "etc",
    "windows",
    "system32",
]


class ActionFirewall:
    """
    Enforces strict perimeter defense for all tool requests.
    Validates tool registration, schema integrity, argument safety,
    path containment, and scope authorization.
    """

    def __init__(self, sandbox: VirtualSandbox = default_sandbox):
        self.sandbox = sandbox

    def inspect_and_execute(self, action: ActionRequest) -> Tuple[FirewallDecision, ActionResult]:
        """
        Inspects the ActionRequest against firewall security policies.
        If allowed, executes the tool safely and returns the result.
        If blocked, halts execution immediately and returns a violation report.
        """
        firewall_decision = self.validate_action(action)
        if not firewall_decision.allowed:
            return firewall_decision, ActionResult(
                success=False,
                error=f"Firewall BLOCKED action: {firewall_decision.reason}",
                tool_name=action.tool_name if hasattr(action, "tool_name") else "unknown",
                operation=action.operation if hasattr(action, "operation") else "unknown"
            )

        # Action is authorized -> Execute inside safe tool boundary
        execution_result = self._execute_tool(action)
        return firewall_decision, execution_result

    def validate_action(self, action: Any) -> FirewallDecision:
        """Inspects an ActionRequest for security violations."""
        violations: List[str] = []

        # 1. Check for malformed request object
        if not isinstance(action, ActionRequest):
            return FirewallDecision(
                allowed=False,
                decision=Decision.BLOCK,
                reason="Action is malformed: Request is not a valid ActionRequest instance.",
                violations=["malformed_action_object"]
            )

        # Check required fields
        if not action.tool_name or not isinstance(action.tool_name, str):
            violations.append("missing_or_invalid_tool_name")
        if not action.operation or not isinstance(action.operation, str):
            violations.append("missing_or_invalid_operation")

        if violations:
            return FirewallDecision(
                allowed=False,
                decision=Decision.BLOCK,
                reason=f"Action is malformed: {', '.join(violations)}.",
                violations=violations
            )

        # 2. Check tool registration
        if action.tool_name not in REGISTERED_TOOLS:
            return FirewallDecision(
                allowed=False,
                decision=Decision.BLOCK,
                reason=f"Unknown tool '{action.tool_name}'. Only registered tools are permitted: {sorted(list(REGISTERED_TOOLS))}.",
                violations=["unknown_tool"]
            )

        # 3. Check allowed operations per tool
        allowed_ops = ALLOWED_OPERATIONS.get(action.tool_name, set())
        if action.operation not in allowed_ops:
            return FirewallDecision(
                allowed=False,
                decision=Decision.BLOCK,
                reason=f"Operation '{action.operation}' is not permitted for tool '{action.tool_name}'. Allowed: {sorted(list(allowed_ops))}.",
                violations=["disallowed_operation"]
            )

        # 4. Scope authorization check
        disallowed_scopes = {"admin", "system_root", "unrestricted", "os_level"}
        if action.requested_scope.lower() in disallowed_scopes:
            return FirewallDecision(
                allowed=False,
                decision=Decision.BLOCK,
                reason=f"Excessive scope '{action.requested_scope}' requested. Elevation of privilege is forbidden.",
                violations=["excessive_scope"]
            )

        # 5. Tool-specific deep parameter validation
        if action.tool_name == "calculator":
            expr = action.arguments.get("expression") or action.target
            if not expr or not isinstance(expr, str):
                return FirewallDecision(
                    allowed=False,
                    decision=Decision.BLOCK,
                    reason="Malformed calculator arguments: 'expression' must be provided as a string.",
                    violations=["malformed_arguments"]
                )

        elif action.tool_name == "virtual_sandbox":
            target = action.target or action.arguments.get("path") or ""
            target_str = str(target).replace("\\", "/").lower()

            # Path traversal check
            if ".." in target_str or target_str.startswith("/") or (len(target_str) > 1 and target_str[1] == ":"):
                return FirewallDecision(
                    allowed=False,
                    decision=Decision.BLOCK,
                    reason=f"Path traversal or absolute system path detected in target '{target}'. Operation blocked.",
                    violations=["path_traversal_attempt"]
                )

            # Protected directory / file access check
            for protected in PROTECTED_PATHS:
                if protected in target_str:
                    return FirewallDecision(
                        allowed=False,
                        decision=Decision.BLOCK,
                        reason=f"Access to protected target containing '{protected}' is strictly forbidden by Action Firewall.",
                        violations=["protected_target_violation"]
                    )

            # If writing, check content
            if action.operation == "write_file":
                if "content" not in action.arguments:
                    return FirewallDecision(
                        allowed=False,
                        decision=Decision.BLOCK,
                        reason="Malformed write_file request: Missing 'content' parameter.",
                        violations=["malformed_arguments"]
                    )

        return FirewallDecision(
            allowed=True,
            decision=Decision.ALLOW,
            reason="ActionRequest verified and authorized by Action Firewall.",
            violations=[]
        )

    def _execute_tool(self, action: ActionRequest) -> ActionResult:
        """Executes the safe tool after firewall clearance."""
        try:
            if action.tool_name == "calculator":
                expr = action.arguments.get("expression") or action.target
                calc_res = SafeCalculator.calculate(expr)
                return ActionResult(
                    success=calc_res["success"],
                    output=calc_res.get("result"),
                    error=calc_res.get("error"),
                    tool_name=action.tool_name,
                    operation=action.operation
                )

            elif action.tool_name == "virtual_sandbox":
                target = action.target or action.arguments.get("path", "")
                if action.operation == "read_file":
                    res = self.sandbox.read_file(target)
                elif action.operation == "write_file":
                    content = action.arguments.get("content", "")
                    res = self.sandbox.write_file(target, content)
                elif action.operation == "delete_file":
                    res = self.sandbox.delete_file(target)
                elif action.operation == "list_dir":
                    res = self.sandbox.list_dir(target)
                else:
                    return ActionResult(
                        success=False,
                        error=f"Unrecognized operation: {action.operation}",
                        tool_name=action.tool_name,
                        operation=action.operation
                    )

                return ActionResult(
                    success=res["success"],
                    output=res if res["success"] else None,
                    error=res.get("error"),
                    tool_name=action.tool_name,
                    operation=action.operation
                )

            return ActionResult(
                success=False,
                error=f"Unsupported tool: {action.tool_name}",
                tool_name=action.tool_name,
                operation=action.operation
            )
        except Exception as e:
            return ActionResult(
                success=False,
                error=f"Execution exception: {str(e)}",
                tool_name=action.tool_name,
                operation=action.operation
            )


# Default global instance
default_action_firewall = ActionFirewall()
