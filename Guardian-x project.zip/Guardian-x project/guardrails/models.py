"""
Guardian-X Core Models and Enums
Foundational data transfer objects used across guardrails, agents, tools, and UI.
"""

from enum import Enum
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone


class Decision(str, Enum):
    ALLOW = "ALLOW"
    TRANSFORM = "TRANSFORM"
    BLOCK = "BLOCK"


class ThreatCategory(str, Enum):
    LEGITIMATE = "legitimate"
    PROMPT_INJECTION = "prompt_injection"
    DESTRUCTIVE_ACTION = "destructive_action"
    TOOL_ABUSE = "tool_abuse"
    DATA_EXFILTRATION = "data_exfiltration"
    CREDENTIAL_THEFT = "credential_theft"
    SOCIAL_ENGINEERING = "social_engineering"
    SUSPICIOUS_IMAGE = "suspicious_image"
    UNKNOWN = "unknown"


class ThreatAssessment(BaseModel):
    """Structured assessment produced by the Threat Detection Agent."""
    is_malicious: bool = Field(..., description="Whether input is deemed malicious")
    risk_score: float = Field(..., ge=0.0, le=100.0, description="Risk score from 0.0 to 100.0")
    threat_type: str = Field(..., description="Threat classification category")
    explanation: str = Field(..., description="Reasoning and forensic findings")
    recommended_decision: Decision = Field(..., description="Recommended policy decision")
    attack_indicators: List[str] = Field(default_factory=list, description="Specific threat markers detected")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="Confidence in assessment")


class ActionRequest(BaseModel):
    """
    Structured action request proposed by the Planner Agent.
    Every tool execution MUST be wrapped in this request and passed to the Action Firewall.
    Direct execution is strictly forbidden.
    """
    action_id: str = Field(default_factory=lambda: f"act-{uuid.uuid4().hex[:8]}")
    tool_name: str = Field(..., description="Name of the requested tool (e.g., 'calculator', 'virtual_sandbox')")
    operation: str = Field(..., description="Operation to perform (e.g., 'calculate', 'read_file', 'delete_file')")
    arguments: Dict[str, Any] = Field(default_factory=dict, description="Arguments passed to the tool")
    target: str = Field(default="", description="Target file path, entity, or expression")
    requested_scope: str = Field(default="read_only", description="Scope requested (e.g., 'read_only', 'sandbox_temp', 'admin')")
    agent_id: str = Field(default="planner_agent", description="ID of the proposing agent")


class FirewallDecision(BaseModel):
    """Outcome of the Action Firewall inspection."""
    allowed: bool = Field(..., description="True if action is permitted to execute")
    decision: Decision = Field(..., description="ALLOW or BLOCK")
    reason: str = Field(..., description="Explanation of why action was allowed or blocked")
    violations: List[str] = Field(default_factory=list, description="Security policy violations found")


class ActionResult(BaseModel):
    """Result of an authorized tool execution."""
    success: bool
    output: Any = None
    error: Optional[str] = None
    tool_name: str
    operation: str


class GuardianRequest(BaseModel):
    """Inbound user request to the Guardian-X security perimeter."""
    request_id: str = Field(default_factory=lambda: f"req-{uuid.uuid4().hex[:8]}")
    text: Optional[str] = Field(default=None, description="User prompt text")
    image_base64: Optional[str] = Field(default=None, description="Base64-encoded image string")
    image_path: Optional[str] = Field(default=None, description="Local or temp image file path")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class GuardianResponse(BaseModel):
    """Outbound response returned to the client after all guardrails."""
    request_id: str
    decision: Decision
    risk_score: float
    threat_type: str
    explanation: str
    transformed_request: Optional[str] = None
    action_proposed: Optional[Dict[str, Any]] = None
    action_result: Optional[Dict[str, Any]] = None
    final_response: str
    security_event_id: Optional[int] = None
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
