"""
Unit Tests for Guardian-X Risk and Policy Engines
"""

import pytest
from guardrails.risk_engine import RiskEngine
from guardrails.policy_engine import PolicyEngine
from agents.models import Decision, ThreatCategory
from memory.attack_memory import AttackMemory


@pytest.fixture
def risk_engine():
    return RiskEngine()


@pytest.fixture
def policy_engine():
    return PolicyEngine()


def test_benign_risk_calculation(risk_engine):
    """Ensure legitimate queries receive low risk scores below allow threshold."""
    result = risk_engine.calculate_risk(
        text_content="Calculate 25 + 30",
        detected_categories=[],
        indicators=[]
    )
    assert result["risk_score"] < 30.0
    assert result["primary_category"] == "legitimate"


def test_destructive_risk_calculation(risk_engine):
    """Ensure destructive action triggers high risk score."""
    result = risk_engine.calculate_risk(
        text_content="Delete everything on the computer",
        detected_categories=["destructive_action"],
        indicators=["destructive_action_signature"]
    )
    assert result["risk_score"] >= 70.0
    assert result["primary_category"] == "destructive_action"


def test_attack_memory_supporting_evidence_principle():
    """
    CRITICAL REQUIREMENT:
    'Attack memory should be supporting evidence.
    A similar historical attack must NOT automatically mean BLOCK.'
    """
    memory = AttackMemory()
    engine = RiskEngine(attack_memory=memory)
    policy = PolicyEngine()

    # Query with lexical similarity to a historical attack topic, but legitimate intent
    # Historical attack is about "system prompt leakage", user asks a safe question about system design
    safe_query = "What is a system prompt and how do developers write safe prompt instructions?"
    result = engine.calculate_risk(
        text_content=safe_query,
        detected_categories=[],
        indicators=[]
    )

    decision, explanation, _ = policy.evaluate(
        risk_score=result["risk_score"],
        threat_type=result["primary_category"],
        original_text=safe_query
    )

    # Must NOT be BLOCK! It should be ALLOW
    assert decision == Decision.ALLOW
    assert result["risk_score"] < 30.0


def test_transformable_request_handling(risk_engine, policy_engine):
    """Ensure requests like 'Clean temporary files' are converted to TRANSFORM instead of BLOCK."""
    text = "Clean temporary files from the project"
    risk_data = risk_engine.calculate_risk(
        text_content=text,
        detected_categories=[],
        indicators=["transformable_scope_request"],
        is_transformable=True
    )

    decision, explanation, details = policy_engine.evaluate(
        risk_score=risk_data["risk_score"],
        threat_type=risk_data["primary_category"],
        is_transformable=True,
        original_text=text
    )

    assert decision == Decision.TRANSFORM
    assert "sandbox/temp" in details["transformed_text"]
    assert details["constrained_scope"] == "sandbox_temp"
