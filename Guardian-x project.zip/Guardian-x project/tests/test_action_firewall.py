"""
Unit Tests for Guardian-X Action Firewall
Verifies zero-trust tool access, perimeter boundaries, and sandboxed execution.
"""

import pytest
from guardrails.action_firewall import ActionFirewall
from guardrails.models import ActionRequest, Decision
from tools.sandbox import VirtualSandbox


@pytest.fixture
def firewall():
    # Use isolated test sandbox instance
    test_sandbox = VirtualSandbox(sandbox_root="tools/virtual_sandbox_test")
    return ActionFirewall(sandbox=test_sandbox)


def test_safe_sandbox_action_allowed(firewall):
    """Test that safe file deletion in temp directory is allowed."""
    action = ActionRequest(
        tool_name="virtual_sandbox",
        operation="delete_file",
        target="temp/example.txt",
        requested_scope="sandbox_temp"
    )
    dec, res = firewall.inspect_and_execute(action)
    assert dec.allowed is True
    assert dec.decision == Decision.ALLOW
    assert res.success is True


def test_protected_target_action_blocked(firewall):
    """CRITICAL: Test that attempts to access protected/ files are blocked."""
    action = ActionRequest(
        tool_name="virtual_sandbox",
        operation="delete_file",
        target="protected/system_config.txt",
        requested_scope="sandbox_temp"
    )
    dec, res = firewall.inspect_and_execute(action)
    assert dec.allowed is False
    assert dec.decision == Decision.BLOCK
    assert "protected" in dec.reason.lower()
    assert res.success is False


def test_unknown_tool_blocked(firewall):
    """Test that unregistered tools are immediately rejected."""
    action = ActionRequest(
        tool_name="bash_shell",
        operation="exec",
        target="rm -rf /"
    )
    dec, res = firewall.inspect_and_execute(action)
    assert dec.allowed is False
    assert dec.decision == Decision.BLOCK
    assert "unknown tool" in dec.reason.lower()
    assert "unknown_tool" in dec.violations


def test_malformed_action_blocked(firewall):
    """Test that malformed requests are blocked."""
    # 1. Non-ActionRequest object
    dec = firewall.validate_action("not_an_action_request_object")
    assert dec.allowed is False
    assert dec.decision == Decision.BLOCK
    assert "malformed" in dec.reason.lower()

    # 2. ActionRequest with missing tool_name
    action_bad = ActionRequest(
        tool_name="",
        operation="calculate"
    )
    dec2 = firewall.validate_action(action_bad)
    assert dec2.allowed is False
    assert dec2.decision == Decision.BLOCK


def test_path_traversal_blocked(firewall):
    """Test that attempts to escape sandbox root with ../ are blocked."""
    action = ActionRequest(
        tool_name="virtual_sandbox",
        operation="read_file",
        target="../../Windows/System32/config/SAM"
    )
    dec, res = firewall.inspect_and_execute(action)
    assert dec.allowed is False
    assert dec.decision == Decision.BLOCK
    assert "path_traversal_attempt" in dec.violations


def test_excessive_scope_blocked(firewall):
    """Test that elevation of privilege (e.g. scope='admin') is rejected."""
    action = ActionRequest(
        tool_name="virtual_sandbox",
        operation="read_file",
        target="data/user_notes.txt",
        requested_scope="admin"
    )
    dec, res = firewall.inspect_and_execute(action)
    assert dec.allowed is False
    assert dec.decision == Decision.BLOCK
    assert "excessive_scope" in dec.violations


def test_safe_calculator_allowed(firewall):
    """Test safe arithmetic calculator evaluation."""
    action = ActionRequest(
        tool_name="calculator",
        operation="calculate",
        arguments={"expression": "125 * 4 + 50"},
        target="125 * 4 + 50"
    )
    dec, res = firewall.inspect_and_execute(action)
    assert dec.allowed is True
    assert res.success is True
    assert res.output == 550
