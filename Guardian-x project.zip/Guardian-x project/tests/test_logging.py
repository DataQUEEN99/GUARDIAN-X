"""
Unit Tests for Guardian-X Security Logging System
Verifies SQLite persistence, statistics computation, and credential redaction.
"""

import pytest
import sqlite3
from pathlib import Path
from security_logging.logger import SecurityLogger, redact_sensitive_data


@pytest.fixture
def temp_logger(tmp_path):
    db_file = tmp_path / "test_security.db"
    return SecurityLogger(db_path=str(db_file))


def test_redact_sensitive_data():
    """Verify that OpenAI keys, bearer tokens, and credentials are scrubbed."""
    raw_secret_text = "Attempted injection using key sk-abcdef1234567890abcdef1234567890"
    scrubbed = redact_sensitive_data(raw_secret_text)
    assert "sk-" not in scrubbed
    assert "[REDACTED_SECRET]" in scrubbed

    bearer_token = "Authorization: Bearer my_secret_token_1234567890abcdef"
    scrubbed_bearer = redact_sensitive_data(bearer_token)
    assert "my_secret_token" not in scrubbed_bearer
    assert "[REDACTED_SECRET]" in scrubbed_bearer


def test_log_event_and_retrieve(temp_logger):
    """Test inserting and reading security events."""
    event_id = temp_logger.log_event(
        request_id="req-test-01",
        input_type="text",
        threat_type="prompt_injection",
        risk_score=95.0,
        decision="BLOCK",
        agent="ThreatDetectionAgent",
        explanation="Attempted jailbreak"
    )
    assert event_id is not None
    assert event_id > 0

    recent = temp_logger.get_recent_events(limit=5)
    assert len(recent) == 1
    assert recent[0]["request_id"] == "req-test-01"
    assert recent[0]["decision"] == "BLOCK"
    assert recent[0]["risk_score"] == 95.0


def test_api_key_never_stored_in_database(temp_logger):
    """CRITICAL: Verify that real API keys are never stored in SQLite database."""
    secret_key = "sk-REALKEYSECRET98765432109876543210"
    temp_logger.log_event(
        request_id="req-leak-test",
        input_type="text",
        threat_type="credential_theft",
        risk_score=99.0,
        decision="BLOCK",
        agent="ThreatDetectionAgent",
        explanation=f"User passed {secret_key} in prompt"
    )

    # Query raw database directly
    with sqlite3.connect(temp_logger.db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT explanation FROM security_events WHERE request_id = 'req-leak-test'")
        row = cursor.fetchone()
        stored_explanation = row[0]

        # The real secret key must NOT exist in the database!
        assert secret_key not in stored_explanation
        assert "[REDACTED_SECRET]" in stored_explanation


def test_get_statistics(temp_logger):
    """Test statistics aggregation."""
    temp_logger.log_event("r1", "text", "legitimate", 5.0, "ALLOW", "Agent", "Safe")
    temp_logger.log_event("r2", "text", "prompt_injection", 95.0, "BLOCK", "Agent", "Blocked")
    temp_logger.log_event("r3", "text", "legitimate", 40.0, "TRANSFORM", "Agent", "Constrained")

    stats = temp_logger.get_statistics()
    assert stats["total_events"] == 3
    assert stats["allowed"] == 1
    assert stats["blocked"] == 1
    assert stats["transformed"] == 1
    assert "prompt_injection" in stats["threat_categories"]
